#ifndef UI_H
#define UI_H

// ============================================================
//   CAMlex - Interface Console (ui.h)
//   Declarations, couleurs ANSI, themes, primitives UI
//   Inclure ce fichier dans tout module qui affiche quelque chose
// ============================================================

#include <string>

// ============================================================
// CONSTANTES ANSI - COULEURS & STYLES
// ============================================================
#define RESET     "\033[0m"
#define BOLD      "\033[1m"
#define DIM       "\033[2m"
#define RED       "\033[31m"
#define GREEN     "\033[32m"
#define YELLOW    "\033[33m"
#define BLUE      "\033[34m"
#define MAGENTA   "\033[35m"
#define CYAN      "\033[36m"
#define WHITE     "\033[37m"
#define ORANGE    "\033[38;5;214m"
#define LBLUE     "\033[38;5;117m"
#define PURPLE    "\033[38;5;141m"
#define GOLD      "\033[38;5;220m"
#define BG_GREEN  "\033[42m"
#define BG_RED    "\033[41m"

// Largeur de la console (colonnes)
#define UI_WIDTH 66

// ============================================================
// HELPERS THEMES (dépendent de User::theme - défini dans user.h)
// ============================================================
// Les fonctions thème lisent la variable globale `me`
std::string themeMain();
std::string themeAccent();
std::string themeHdr();

// ============================================================
// HELPERS NIVEAU / MAÎTRISE
// ============================================================
std::string masteryName (int xp);
std::string masteryColor(int xp);

// ============================================================
// PRIMITIVES D'AFFICHAGE
// ============================================================

/** Efface le terminal */
void cls();

/** Attend que l'utilisateur appuie sur Entrée */
void pauseKey();

/** Ligne horizontale colorée */
void hline(const std::string& color = CYAN, char c = '-');

/** Encadré avec titre centré */
void titleBox(const std::string& title, const std::string& color = CYAN);

/** Texte centré sur la largeur UI_WIDTH */
void centered(const std::string& s, const std::string& color = WHITE);

/** Élément de menu numéroté */
void menuItem(int n, const std::string& label,
              const std::string& icon = ">>");

/** Messages système colorés */
void ok  (const std::string& m);   // [OK]  vert
void err (const std::string& m);   // [!!]  rouge
void info(const std::string& m);   // [i]   bleu
void warn(const std::string& m);   // [*]   orange

/** Barre de progression ASCII */
void progressBar(int val, int max, int w = 40);

/** Saisie utilisateur avec prompt coloré ; retourne la chaîne */
std::string prompt(const std::string& msg);

/** Délai logiciel (pas de dépendance OS) */
void sleepMs(int ms);

/** Affiche les gemmes et points du joueur courant */
void showGems();

// ============================================================
// LOGO ASCII & MASCOTTE
// ============================================================

/** Affiche le logo CAMlex en ASCII art */
void printLogo();

/**
 * Affiche la mascotte Phénix (3 frames : 0=normal, 1=ailes écartées,
 * 2=clin d'oeil) avec une bulle de message optionnelle
 */
void mascotFrame(int frame, const std::string& msg = "");

/** Alias pratique : mascotFrame(0, msg) */
void mascot(const std::string& msg = "");

// ============================================================
// DÉCLARATIONS DES ÉCRANS
// ============================================================

void splashScreen();
void loginScreen();
void langSelect();
void mainMenu();

void lessonsMenu();
void quizScreen();
void progressScreen();
void dictionaryScreen();

void miniGamesMenu();
void hangmanGame();
void memoryGame();
void spellingBeeGame();

void srsScreen();
void culturalScreen();
void leaderboardScreen();

void gamificationScreen();
void dailyChallengeScreen();
void gemsShopScreen();

void aiTutorScreen();
void customizationScreen();
void aboutScreen();

#endif /* UI_H */
