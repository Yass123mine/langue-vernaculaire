// ============================================================
//   CAMlex - Interface Console (ui.cpp)
//   Implémentation de toutes les fonctions d'affichage et écrans
//
//   Dépendances :
//     - ui.h          (déclarations + couleurs)
//     - data.h        (Language, Lesson, Vocab, Proverb, CulturalStory,
//                      Question, langs, findLang, initData)
//     - user.h        (User, me, loggedIn, saveUser, loadUser, genCode)
//     - srs.h         (SRSCard, mySRSCards, sm2Update,
//                      saveSRS, loadSRS, initSRSForLang)
//
//   Compilation (exemple complet) :
//     g++ -std=c++11 -o camlex main.cpp ui.cpp data.cpp user.cpp srs.cpp -lm
// ============================================================

#include "ui.h"

// Inclure les headers du projet (adapter les noms si besoin)
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <fstream>
#include <algorithm>
#include <iomanip>
#include <set>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <cmath>

#ifdef _WIN32
  #include <windows.h>
  #define CLEAR_CMD "cls"
#else
  #define CLEAR_CMD "clear"
#endif

// ──────────────────────────────────────────────
// Ces symboles sont définis dans les autres modules.
// Déclaration externe pour éviter les inclusions circulaires.
// ──────────────────────────────────────────────
struct Vocab {
    std::string word, french, pronunc, culturalNote;
};
struct Proverb {
    std::string original, french, meaning;
};
struct CulturalStory {
    std::string title, text;
};
struct Lesson {
    int id;
    std::string title, intro;
    std::vector<Vocab> vocab;
    int xpReward;
};
struct Question {
    std::string text;
    std::string opts[4];
    int correct;
    std::string tip;
};
struct Language {
    std::string code, name, desc, region;
    std::vector<Lesson>        lessons;
    std::vector<Question>      quiz;
    std::vector<Proverb>       proverbs;
    std::vector<CulturalStory> stories;
};
struct SRSCard {
    std::string langCode, word, french;
    int   repetitions, interval;
    float easinessFactor;
    long  nextReview;
};
struct User {
    std::string name, code, lang;
    int  xp, streak, lessonsCompleted, quizBest;
    long lastLogin;
    int  gems, achievementPoints, leagueRank, challengeWins;
    int  xpMultiplier;
    long lastDailyChallenge;
    int  theme, totalWordsLearned, miniGameBest, srsCardsReviewed;
};

// Globaux définis dans les autres modules
extern std::vector<Language> langs;
extern User                  me;
extern bool                  loggedIn;
extern std::vector<SRSCard>  mySRSCards;

// Fonctions des autres modules utilisées ici
extern bool      saveUser(const User& u);
extern bool      loadUser(const std::string& code, User& u);
extern std::string genCode();
extern Language* findLang(const std::string& code);
extern void      saveSRS();
extern void      loadSRS();
extern void      initSRSForLang(const std::string& langCode);
extern void      sm2Update(SRSCard& card, int q);

// ============================================================
// THEME HELPERS
// ============================================================

std::string themeMain() {
    return me.theme==1 ? "\033[38;5;33m"
         : me.theme==2 ? "\033[38;5;198m"
         : CYAN;
}
std::string themeAccent() {
    return me.theme==1 ? "\033[38;5;220m"
         : me.theme==2 ? "\033[38;5;118m"
         : YELLOW;
}
std::string themeHdr() {
    return me.theme==1 ? "\033[38;5;99m"
         : me.theme==2 ? "\033[38;5;226m"
         : ORANGE;
}

// ============================================================
// MAÎTRISE
// ============================================================

std::string masteryName(int xp) {
    if (xp >= 500) return "DIAMANT";
    if (xp >= 300) return "PLATINE";
    if (xp >= 150) return "OR";
    if (xp >= 50)  return "ARGENT";
    return "BRONZE";
}

std::string masteryColor(int xp) {
    if (xp >= 500) return "\033[38;5;51m";
    if (xp >= 300) return "\033[38;5;147m";
    if (xp >= 150) return GOLD;
    if (xp >= 50)  return "\033[37m";
    return "\033[38;5;208m";
}

// ============================================================
// PRIMITIVES D'AFFICHAGE
// ============================================================

void cls() { system(CLEAR_CMD); }

void pauseKey() {
    std::cout << "\n" << DIM
              << "  Appuyez sur ENTREE pour continuer..." << RESET;
    std::cin.ignore(10000, '\n');
    std::cin.get();
}

void hline(const std::string& color, char c) {
    std::cout << color;
    for (int i = 0; i < UI_WIDTH; i++) std::cout << c;
    std::cout << RESET << "\n";
}

void titleBox(const std::string& title, const std::string& color) {
    int inner = UI_WIDTH - 2;
    int pad   = (inner - (int)title.size()) / 2;
    int rpad  = inner - pad - (int)title.size();
    if (pad  < 0) pad  = 0;
    if (rpad < 0) rpad = 0;
    std::cout << color
              << "+" << std::string(inner, '=') << "+\n"
              << "|" << std::string(pad, ' ')
              << BOLD << WHITE << title << RESET << color
              << std::string(rpad, ' ') << "|\n"
              << "+" << std::string(inner, '=') << "+"
              << RESET << "\n";
}

void centered(const std::string& s, const std::string& color) {
    int sp = (UI_WIDTH - (int)s.size()) / 2;
    if (sp < 0) sp = 0;
    std::cout << color << std::string(sp, ' ') << s << RESET << "\n";
}

void menuItem(int n, const std::string& label,
              const std::string& icon) {
    std::cout << CYAN  << "  " << icon << " " << RESET
              << YELLOW << "[" << n << "]" << RESET
              << "  " << label << "\n";
}

void ok  (const std::string& m) { std::cout<<"\n"<<GREEN <<" [OK] "<<m<<RESET<<"\n\n"; }
void err (const std::string& m) { std::cout<<"\n"<<RED   <<" [!!] "<<m<<RESET<<"\n\n"; }
void info(const std::string& m) { std::cout<<"\n"<<LBLUE <<" [i]  "<<m<<RESET<<"\n\n"; }
void warn(const std::string& m) { std::cout<<"\n"<<ORANGE<<" [*]  "<<m<<RESET<<"\n\n"; }

void progressBar(int val, int max, int w) {
    float pct    = max > 0 ? (float)val / max : 0.f;
    int   filled = (int)(pct * w);
    std::cout << "  " << CYAN << "[";
    for (int i = 0; i < w; i++)
        std::cout << (i < filled ? GREEN"#" : DIM"-") << RESET;
    std::cout << CYAN << "] " << YELLOW << BOLD
              << (int)(pct * 100) << "%" << RESET << "\n";
}

std::string prompt(const std::string& msg) {
    std::cout << CYAN << "  > " << RESET << msg;
    std::string s;
    std::getline(std::cin, s);
    while (!s.empty() && (s.back()=='\r' || s.back()==' '))
        s.pop_back();
    return s;
}

void sleepMs(int ms) {
    /* Délai logiciel portable — remplacer par
       std::this_thread::sleep_for() si C++11 <thread> est disponible */
    volatile long n = (long)ms * 100000L;
    while (n-- > 0);
}

void showGems() {
    std::cout << GOLD   << "  Gemmes: "  << me.gems << " [*]" << RESET
              << "  |  " << PURPLE << "Points: " << me.achievementPoints << RESET
              << "  |  " << masteryColor(me.xp)  << masteryName(me.xp) << RESET
              << "\n";
}

// ============================================================
// LOGO ASCII & MASCOTTE PHÉNIX
// ============================================================

void printLogo() {
    std::cout << themeHdr() << BOLD;
    std::cout << "\n";
    std::cout << "   ______  ___    __  ___ __              \n";
    std::cout << "  / ____/ /   |  /  |/  // /  ___  _  __ \n";
    std::cout << " / /     / /| | / /|_/ // /  / _ \\| |/ / \n";
    std::cout << "/ /___  / ___ |/ /  / // /__/  __/>  <   \n";
    std::cout << "\\____/ /_/  |_/_/  /_//_____/\\___//_/|_|  \n";
    std::cout << RESET;
    centered("Apprends les Langues du Cameroun  |  v2.0", DIM);
    std::cout << "\n";
}

void mascotFrame(int frame, const std::string& msg) {
    std::cout << themeHdr();
    if (frame == 0) {
        // Frame normale
        std::cout << "      (  )\n";
        std::cout << "     /|  |\\\n";
        std::cout << "    / |  | \\\n";
        std::cout << "   /  (oo)  \\\n";
        std::cout << "  /  / ~~ \\  \\\n";
        std::cout << "      \\__/\n";
        std::cout << "     PHENIX\n";
    } else if (frame == 1) {
        // Ailes écartées (battement)
        std::cout << "       (  )\n";
        std::cout << "     -/|  |\\ -\n";
        std::cout << "      / |  | \\\n";
        std::cout << "     /  (oo)  \\\n";
        std::cout << "    /  / ~~ \\  \\\n";
        std::cout << "        \\__/\n";
        std::cout << "       PHENIX\n";
    } else {
        // Clin d'œil (clignement)
        std::cout << "      (  )\n";
        std::cout << "     /|  |\\\n";
        std::cout << "    / |  | \\\n";
        std::cout << "   /  (--)  \\\n";
        std::cout << "  /  / ~~ \\  \\\n";
        std::cout << "      \\__/\n";
        std::cout << "     PHENIX\n";
    }
    std::cout << RESET;

    // Bulle de dialogue
    if (!msg.empty()) {
        int inner = (int)msg.size() + 4;
        if (inner < 12) inner = 12;
        std::cout << "\n" << YELLOW
                  << "  +" << std::string(inner, '-') << "+\n"
                  << "  | " << WHITE << msg
                  << YELLOW << "  |\n"
                  << "  +" << std::string(inner, '-') << "+\n"
                  << RESET;
    }
}

void mascot(const std::string& msg) { mascotFrame(0, msg); }

// ============================================================
// ÉCRAN : SPLASH
// ============================================================

void splashScreen() {
    cls();
    printLogo();
    mascot("Bienvenue! Pret a apprendre?");
    std::cout << "\n";
    centered("Preservons les langues camerounaises", GREEN);
    centered("v2.0 - Gamification + IA + Mini-jeux + SRS", DIM);
    std::cout << "\n";
}

// ============================================================
// ÉCRAN : CONNEXION / INSCRIPTION
// ============================================================

void loginScreen() {
    while (true) {
        cls();
        printLogo();
        hline(CYAN, '=');
        centered("CONNEXION  /  INSCRIPTION", YELLOW);
        hline(CYAN, '=');
        std::cout << "\n";
        menuItem(1, "Creer un nouveau compte");
        menuItem(2, "Se connecter avec mon code");
        menuItem(0, "Quitter", "XX");
        std::cout << "\n";

        std::string ch = prompt("Votre choix: ");

        if (ch == "1") {
            // ── Inscription ──────────────────────────────────
            cls();
            titleBox("CREER UN COMPTE", GREEN);
            mascot("Super! Creeons ton profil!");
            std::cout << "\n";
            std::string nom = prompt("Votre prenom: ");
            if (nom.empty()) {
                err("Le nom est obligatoire!");
                pauseKey();
                continue;
            }
            me.name               = nom;
            me.code               = genCode();
            me.lang               = "";
            me.xp                 = 0;
            me.streak             = 0;
            me.lessonsCompleted   = 0;
            me.quizBest           = 0;
            me.lastLogin          = (long)time(nullptr);
            me.gems               = 10;
            me.achievementPoints  = 0;
            me.leagueRank         = 0;
            me.challengeWins      = 0;
            me.xpMultiplier       = 1;
            me.lastDailyChallenge = 0;
            me.theme              = 0;
            me.totalWordsLearned  = 0;
            me.miniGameBest       = 0;
            me.srsCardsReviewed   = 0;
            saveUser(me);
            loggedIn = true;

            ok("Compte cree! +10 gemmes de bienvenue!");
            hline(YELLOW, '=');
            centered("VOTRE CODE (GARDEZ-LE!)", YELLOW);
            centered(me.code, BOLD + std::string(ORANGE));
            hline(YELLOW, '=');
            std::cout << "\n  Bienvenue, "
                      << GREEN << BOLD << me.name << RESET << "!\n";
            pauseKey();
            return;

        } else if (ch == "2") {
            // ── Connexion ─────────────────────────────────────
            cls();
            titleBox("SE CONNECTER", CYAN);
            std::cout << "\n";
            std::string code = prompt("Entrez votre code: ");
            if (loadUser(code, me)) {
                loggedIn = true;
                long   now  = (long)time(nullptr);
                double days = (double)(now - me.lastLogin) / 86400.0;
                if (days >= 1.0 && days < 2.0) {
                    me.streak++;
                    me.gems += me.streak;
                } else if (days >= 2.0) {
                    me.streak = 0;
                }
                me.lastLogin = now;
                saveUser(me);
                loadSRS();
                ok("Connexion reussie!");
                std::cout << "  Bon retour, "
                          << GREEN << BOLD << me.name << RESET << "!\n";
                if (me.streak > 1)
                    std::cout << "  " << ORANGE << "Serie: " << me.streak
                              << " jours! +" << me.streak << " gemmes!\n"
                              << RESET;
                pauseKey();
                return;
            } else {
                err("Code introuvable. Verifiez et reessayez.");
                pauseKey();
            }

        } else if (ch == "0") {
            cls();
            centered("A bientot!", CYAN);
            exit(0);
        } else {
            err("Choix invalide!");
        }
    }
}

// ============================================================
// ÉCRAN : SÉLECTION DE LANGUE
// ============================================================

void langSelect() {
    cls();
    titleBox("CHOISIR UNE LANGUE", ORANGE);
    mascot("Quelle langue veux-tu apprendre?");
    std::cout << "\n";

    for (int i = 0; i < (int)langs.size(); i++) {
        auto& l = langs[i];
        hline(CYAN, '-');
        std::cout << YELLOW << "  [" << (i+1) << "] "
                  << BOLD   << l.name << RESET
                  << "\n  " << l.desc
                  << "\n  " << DIM << "Region: " << l.region << RESET << "\n";
    }
    hline(CYAN, '-');
    menuItem(0, "Retour", "<<");
    std::cout << "\n";

    std::string ch  = prompt("Votre choix: ");
    if (ch == "0") return;
    int idx = ch.empty() ? -1 : (std::stoi(ch) - 1);
    if (idx >= 0 && idx < (int)langs.size()) {
        me.lang = langs[idx].code;
        saveUser(me);
        initSRSForLang(me.lang);
        ok("Langue selectionnee: " + langs[idx].name);
        sleepMs(400);
    } else {
        err("Choix invalide.");
    }
}

// ============================================================
// ÉCRAN : AFFICHAGE D'UNE LEÇON
// ============================================================

void showLesson(Language& lang, Lesson& les) {
    cls();
    titleBox("LECON " + std::to_string(les.id) + ": " + les.title, BLUE);
    std::cout << "\n  " << WHITE << les.intro << RESET << "\n\n";

    // En-tête du tableau
    std::cout << CYAN
              << "  +" << std::string(14,'-') << "+" << std::string(16,'-') << "+"
              << std::string(14,'-') << "+" << std::string(20,'-') << "+\n"
              << "  |" << YELLOW << BOLD << std::left << std::setw(14) << (" " + lang.name)
              << RESET << CYAN << "|"
              << YELLOW << BOLD << std::setw(16) << " Francais"
              << RESET << CYAN << "|"
              << YELLOW << BOLD << std::setw(14) << " Prononciat."
              << RESET << CYAN << "|"
              << YELLOW << BOLD << std::setw(20) << " Note culturelle"
              << RESET << CYAN << "|\n"
              << "  +" << std::string(14,'-') << "+" << std::string(16,'-') << "+"
              << std::string(14,'-') << "+" << std::string(20,'-') << "+\n"
              << RESET;

    for (auto& v : les.vocab) {
        std::string wd = " " + v.word;
        std::string fr = " " + v.french;
        std::string pr = " " + v.pronunc;
        std::string cn = " " + (v.culturalNote.size() > 18
                                ? v.culturalNote.substr(0,17) + "."
                                : v.culturalNote);
        std::cout << CYAN << "  |" << GREEN  << std::left << std::setw(14) << wd
                  << CYAN << "|" << RESET    << std::setw(16) << fr
                  << CYAN << "|" << DIM      << std::setw(14) << pr
                  << RESET << CYAN << "|" << DIM << std::setw(20) << cn
                  << RESET << CYAN << "|\n";
    }
    std::cout << CYAN << "  +"
              << std::string(14,'-') << "+" << std::string(16,'-') << "+"
              << std::string(14,'-') << "+" << std::string(20,'-') << "+\n"
              << RESET;

    // Récompenses
    int xpGained = les.xpReward * me.xpMultiplier;
    me.xp               += xpGained;
    me.lessonsCompleted++;
    me.totalWordsLearned += (int)les.vocab.size();
    me.gems              += 2;
    me.achievementPoints += 10;
    saveUser(me);

    ok("+" + std::to_string(xpGained) + " XP + 2 gemmes pour cette lecon!");
    if (me.xpMultiplier > 1)
        info("Multiplicateur x" + std::to_string(me.xpMultiplier) + " actif!");
    std::cout << "  " << masteryColor(me.xp) << "Niveau: "
              << masteryName(me.xp) << RESET << "\n";
    pauseKey();
}

// ============================================================
// ÉCRAN : MENU LEÇONS
// ============================================================

void lessonsMenu() {
    if (me.lang.empty()) { langSelect(); if (me.lang.empty()) return; }
    Language* lang = findLang(me.lang);
    if (!lang) return;

    while (true) {
        cls();
        titleBox("LECONS - " + lang->name, BLUE);
        std::cout << "\n  " << CYAN << "Langue: "
                  << YELLOW << BOLD << lang->name << RESET << "\n";
        showGems();
        std::cout << "\n";

        for (int i = 0; i < (int)lang->lessons.size(); i++) {
            std::cout << "  " << CYAN << " -> " << RESET
                      << YELLOW << "[" << (i+1) << "] " << RESET
                      << lang->lessons[i].title
                      << DIM << "  (+" << lang->lessons[i].xpReward
                      << " XP)" << RESET << "\n";
        }
        std::cout << "\n";
        menuItem((int)lang->lessons.size()+1, "Changer de langue", ">>");
        menuItem(0, "Retour au menu", "<<");
        std::cout << "\n";

        std::string ch = prompt("Choisir une lecon: ");
        if (ch == "0") return;
        int n = ch.empty() ? -1 : std::stoi(ch);
        if (n == (int)lang->lessons.size() + 1) {
            langSelect();
            lang = findLang(me.lang);
            if (!lang) return;
        } else if (n >= 1 && n <= (int)lang->lessons.size()) {
            showLesson(*lang, lang->lessons[n-1]);
        } else {
            err("Choix invalide.");
        }
    }
}

// ============================================================
// ÉCRAN : QUIZ
// ============================================================

void quizScreen() {
    if (me.lang.empty()) {
        err("Choisissez d'abord une langue!"); pauseKey(); return;
    }
    Language* lang = findLang(me.lang);
    if (!lang || lang->quiz.empty()) {
        info("Pas encore de quiz."); pauseKey(); return;
    }

    cls();
    titleBox("QUIZ - " + lang->name, MAGENTA);
    mascot("Es-tu pret pour le quiz?");
    std::cout << "\n  " << WHITE << lang->quiz.size()
              << " questions sur " << lang->name << "\n\n";
    std::cout << "  Repondez avec A, B, C ou D.\n\n";
    pauseKey();

    int score = 0, total = (int)lang->quiz.size();
    std::vector<std::string> wrongWords;

    for (int i = 0; i < total; i++) {
        auto& q = lang->quiz[i];
        cls();
        std::cout << "\n" << MAGENTA;
        hline(MAGENTA, '=');
        std::cout << "  Question " << (i+1) << " / " << total << "\n";
        hline(MAGENTA, '-');
        std::cout << RESET;
        progressBar(i, total, 46);
        std::cout << "\n" << WHITE << BOLD << "  " << q.text << RESET << "\n\n";

        char labels[] = {'A','B','C','D'};
        for (int j = 0; j < 4; j++)
            if (!q.opts[j].empty())
                std::cout << "  " << CYAN << "[" << labels[j] << "] "
                          << RESET << q.opts[j] << "\n";
        std::cout << "\n";

        std::string ans = prompt("Votre reponse (A/B/C/D): ");
        int userIdx = -1;
        if (!ans.empty()) {
            char c = (char)toupper(ans[0]);
            if (c >= 'A' && c <= 'D') userIdx = c - 'A';
        }

        if (userIdx == q.correct) {
            score++;
            int xpE = 10 * me.xpMultiplier;
            me.xp += xpE; me.gems++;
            ok("Bonne reponse! +" + std::to_string(xpE) + " XP + 1 gemme");
        } else {
            wrongWords.push_back(q.opts[q.correct]);
            err("Mauvaise reponse!");
            std::cout << "  " << CYAN << "Bonne reponse: " << GREEN
                      << labels[q.correct] << " - " << q.opts[q.correct]
                      << RESET << "\n";
        }
        std::cout << "  " << DIM << "Astuce: " << q.tip << RESET << "\n";
        pauseKey();
    }

    int pct = (int)((float)score / total * 100);
    if (pct > me.quizBest) me.quizBest = pct;
    me.achievementPoints += score * 5;
    saveUser(me);

    // Résultats
    cls();
    titleBox("RESULTATS DU QUIZ", YELLOW);
    std::cout << "\n";
    if      (pct >= 80) mascot("Excellent! Tu es un champion!");
    else if (pct >= 50) mascot("Bien joue! Continue comme ca!");
    else                mascot("Ne lache pas! Revise et reessaie!");

    std::cout << "\n  Score: "
              << (pct>=80 ? GREEN : pct>=50 ? YELLOW : RED)
              << BOLD << score << "/" << total
              << "  (" << pct << "%)" << RESET << "\n\n";
    progressBar(score, total, 46);
    std::cout << "\n  XP gagnes  : " << ORANGE
              << "+" << score * 10 * me.xpMultiplier << RESET << "\n"
              << "  Gemmes     : " << GOLD
              << "+" << score << " [*]" << RESET << "\n";

    if (!wrongWords.empty()) {
        std::cout << "\n  " << LBLUE << "[IA] Mots a retravailler:\n" << RESET;
        for (auto& w : wrongWords)
            std::cout << "  " << RED << "  - " << w << RESET << "\n";
        std::cout << "  " << LBLUE
                  << "[IA] Conseil: Utilisez la Revision SRS!\n" << RESET;
    }
    pauseKey();
}

// ============================================================
// ÉCRAN : PROGRESSION
// ============================================================

void progressScreen() {
    cls();
    titleBox("MA PROGRESSION", GREEN);
    std::cout << "\n";

    hline(CYAN, '-');
    std::cout << "  " << YELLOW << BOLD << "Joueur : " << RESET << me.name << "\n"
              << "  " << DIM   << "Code   : " << me.code << RESET << "\n"
              << "  Langue : " << GREEN << (me.lang.empty() ? "Aucune" : me.lang) << RESET << "\n"
              << "  Serie  : " << ORANGE << me.streak << " jour(s)" << RESET << "\n";
    hline(CYAN, '-');

    std::cout << "\n  Niveau: "
              << masteryColor(me.xp) << BOLD << masteryName(me.xp) << RESET << "\n";

    int nextLvl = 50;
    if      (me.xp >= 300) nextLvl = 500;
    else if (me.xp >= 150) nextLvl = 300;
    else if (me.xp >= 50)  nextLvl = 150;
    std::cout << "\n  " << ORANGE << "XP: " << me.xp << " / " << nextLvl << "\n" << RESET;
    progressBar(me.xp, nextLvl, 40);

    std::cout << "\n";
    showGems();
    std::cout << "\n"
              << "  Lecons completees   : " << YELLOW << me.lessonsCompleted   << RESET << "\n"
              << "  Mots appris         : " << YELLOW << me.totalWordsLearned  << RESET << "\n"
              << "  Meilleur quiz       : " << YELLOW << me.quizBest << "%"    << RESET << "\n"
              << "  Victoires defi      : " << YELLOW << me.challengeWins      << RESET << "\n"
              << "  Cartes SRS revisees : " << YELLOW << me.srsCardsReviewed   << RESET << "\n"
              << "  Multiplicateur XP   : " << ORANGE << "x" << me.xpMultiplier << RESET << "\n";

    // Badges
    std::cout << "\n  " << YELLOW << "BADGES:\n" << RESET;
    bool any = false;
    if (me.xp >= 50)            { std::cout<<"  \033[37m[*] ARGENT - Debutant\n"           <<RESET; any=true; }
    if (me.xp >= 150)           { std::cout<<"  "<<GOLD         <<"[*] OR - Intermediaire\n"<<RESET; any=true; }
    if (me.xp >= 300)           { std::cout<<"  \033[38;5;147m[*] PLATINE - Avance\n"       <<RESET; any=true; }
    if (me.xp >= 500)           { std::cout<<"  \033[38;5;51m[*] DIAMANT - Expert\n"        <<RESET; any=true; }
    if (me.streak >= 7)         { std::cout<<"  "<<ORANGE  <<"[*] ASSIDU - 7 jours de serie!\n"<<RESET; any=true; }
    if (me.lessonsCompleted>=5) { std::cout<<"  "<<GREEN   <<"[*] STUDIEUX - 5 lecons!\n"       <<RESET; any=true; }
    if (me.challengeWins >= 3)  { std::cout<<"  "<<MAGENTA <<"[*] CHAMPION - 3 defis gagnes!\n" <<RESET; any=true; }
    if (!any)
        std::cout << "  " << DIM
                  << "Completez des lecons pour gagner des badges!\n" << RESET;
    pauseKey();
}

// ============================================================
// ÉCRAN : DICTIONNAIRE
// ============================================================

void dictionaryScreen() {
    cls();
    titleBox("DICTIONNAIRE", CYAN);
    std::cout << "\n";
    for (int i = 0; i < (int)langs.size(); i++)
        menuItem(i+1, langs[i].name);
    menuItem(0, "Retour", "<<");
    std::cout << "\n";

    std::string ch = prompt("Choisir une langue: ");
    if (ch == "0") return;
    int idx = ch.empty() ? -1 : (std::stoi(ch)-1);
    if (idx < 0 || idx >= (int)langs.size()) { err("Choix invalide."); return; }

    Language& lang = langs[idx];
    std::string srch = prompt("Mot a chercher (francais ou " + lang.name + "): ");
    std::transform(srch.begin(), srch.end(), srch.begin(), ::tolower);

    cls();
    titleBox("RESULTATS - " + lang.name, CYAN);
    bool found = false;
    for (auto& les : lang.lessons) {
        for (auto& v : les.vocab) {
            std::string wl = v.word, fl = v.french;
            std::transform(wl.begin(), wl.end(), wl.begin(), ::tolower);
            std::transform(fl.begin(), fl.end(), fl.begin(), ::tolower);
            if (wl.find(srch)!=std::string::npos ||
                fl.find(srch)!=std::string::npos) {
                std::cout << "\n  " << GREEN << BOLD << v.word << RESET
                          << " -> " << v.french
                          << CYAN << "  [" << v.pronunc << "]" << RESET << "\n"
                          << "  " << DIM << "Note: " << v.culturalNote << RESET << "\n"
                          << "  " << DIM << "Lecon: " << les.title << RESET << "\n";
                found = true;
            }
        }
    }
    if (!found) warn("Aucun resultat pour \"" + srch + "\"");
    pauseKey();
}

// ============================================================
// MINI-JEU : PENDU (Hangman)
// ============================================================

static void drawHangman(int errors) {
    static const char* parts[] = {
        "  +---+\n  |   |\n  |\n  |\n  |\n  |\n  ===",
        "  +---+\n  |   |\n  |   O\n  |\n  |\n  |\n  ===",
        "  +---+\n  |   |\n  |   O\n  |   |\n  |\n  |\n  ===",
        "  +---+\n  |   |\n  |   O\n  |  /|\n  |\n  |\n  ===",
        "  +---+\n  |   |\n  |   O\n  |  /|\\\n  |\n  |\n  ===",
        "  +---+\n  |   |\n  |   O\n  |  /|\\\n  |  /\n  |\n  ===",
        "  +---+\n  |   |\n  |   O\n  |  /|\\\n  |  / \\\n  |\n  ==="
    };
    int e = errors < 0 ? 0 : errors > 6 ? 6 : errors;
    std::cout << "\n  " << RED << parts[e] << RESET << "\n\n";
}

void hangmanGame() {
    if (me.lang.empty()) { err("Choisissez d'abord une langue!"); pauseKey(); return; }
    Language* lang = findLang(me.lang);
    if (!lang) return;

    std::vector<std::pair<std::string,std::string>> words;
    for (auto& les : lang->lessons)
        for (auto& v : les.vocab)
            words.push_back({v.word, v.french});
    if (words.empty()) { info("Pas de mots."); pauseKey(); return; }

    srand((unsigned)time(nullptr));
    auto& chosen  = words[rand() % words.size()];
    std::string word = chosen.first, hint = chosen.second;
    std::string wordUp = word;
    std::transform(wordUp.begin(), wordUp.end(), wordUp.begin(), ::toupper);

    std::set<char> guessed;
    int errors = 0, maxErrors = 6;

    while (errors < maxErrors) {
        cls();
        titleBox("PENDU LINGUISTIQUE", MAGENTA);
        std::cout << "  " << DIM << "Langue: " << lang->name
                  << "  |  Indice: " << YELLOW << hint << RESET << "\n";
        drawHangman(errors);

        // Affichage du mot masqué
        std::cout << "  ";
        bool allDone = true;
        for (char c : wordUp) {
            if (c == ' ') { std::cout << "  "; continue; }
            if (guessed.count(c) || guessed.count((char)::tolower(c)))
                std::cout << GREEN << c << " " << RESET;
            else { std::cout << "_ "; allDone = false; }
        }
        std::cout << "\n\n  Lettres essayees: " << YELLOW;
        for (char c : guessed) std::cout << c << " ";
        std::cout << RESET
                  << "\n  Erreurs: " << RED << errors << "/" << maxErrors << RESET << "\n\n";

        if (allDone) {
            ok("Bravo! Mot devine: " + word);
            int xpG = (maxErrors - errors) * 5 * me.xpMultiplier;
            me.xp += xpG; me.gems += 3; me.achievementPoints += 15;
            if (xpG > me.miniGameBest) me.miniGameBest = xpG;
            saveUser(me);
            std::cout << "  " << ORANGE << "+" << xpG << " XP + 3 gemmes!" << RESET << "\n";
            pauseKey();
            return;
        }

        std::string guess = prompt("Entrez une lettre: ");
        if (guess.empty()) continue;
        char g = (char)toupper(guess[0]);
        if (guessed.count(g)) { warn("Lettre deja essayee!"); sleepMs(200); continue; }
        guessed.insert(g);
        bool hit = false;
        for (char c : wordUp) if (c == g) { hit = true; break; }
        if (!hit) errors++;
    }

    drawHangman(6);
    err("Perdu! Le mot etait: " + word);
    pauseKey();
}

// ============================================================
// MINI-JEU : MEMORY MATCH
// ============================================================

void memoryGame() {
    if (me.lang.empty()) { err("Choisissez d'abord une langue!"); pauseKey(); return; }
    Language* lang = findLang(me.lang);
    if (!lang) return;

    std::vector<std::pair<std::string,std::string>> words;
    for (auto& les : lang->lessons)
        for (auto& v : les.vocab)
            words.push_back({v.word, v.french});
    if ((int)words.size() < 4) { info("Pas assez de mots."); pauseKey(); return; }

    srand((unsigned)time(nullptr));
    std::vector<int> idx;
    while ((int)idx.size() < 4) {
        int r = rand() % (int)words.size();
        bool dup = false;
        for (int x : idx) if (x==r) { dup=true; break; }
        if (!dup) idx.push_back(r);
    }

    struct Card { std::string content; bool revealed, matched; int pairId; };
    std::vector<Card> board;
    for (int i = 0; i < 4; i++) {
        board.push_back({words[idx[i]].first,  false, false, i});
        board.push_back({words[idx[i]].second, false, false, i});
    }
    for (int i = 7; i > 0; i--) {
        int j = rand() % (i+1);
        std::swap(board[i], board[j]);
    }

    int tries = 0, matched = 0;

    while (matched < 4) {
        cls();
        titleBox("MEMORY - " + lang->name, CYAN);
        std::cout << "  Paires: " << GREEN << matched << "/4" << RESET
                  << "  |  Essais: " << YELLOW << tries << RESET << "\n\n";

        auto drawBoard = [&]() {
            for (int i = 0; i < 8; i++) {
                std::cout << "  ";
                if (board[i].matched)
                    std::cout << GREEN  << "[" << std::setw(12) << board[i].content << "]" << RESET;
                else if (board[i].revealed)
                    std::cout << YELLOW << "[" << std::setw(12) << board[i].content << "]" << RESET;
                else
                    std::cout << CYAN   << "[" << std::setw(4)  << (i+1) << std::setw(8) << "]" << RESET;
                if ((i+1) % 4 == 0) std::cout << "\n";
            }
            std::cout << "\n";
        };
        drawBoard();

        std::string s1 = prompt("Premiere carte (1-8): ");
        int c1 = s1.empty() ? -1 : std::stoi(s1)-1;
        if (c1<0||c1>=8||board[c1].matched||board[c1].revealed) {
            warn("Invalide."); sleepMs(200); continue;
        }
        board[c1].revealed = true;

        cls();
        titleBox("MEMORY - " + lang->name, CYAN);
        std::cout << "  Paires: " << GREEN << matched << "/4" << RESET
                  << "  |  Essais: " << YELLOW << tries << RESET << "\n\n";
        drawBoard();

        std::string s2 = prompt("Deuxieme carte (1-8): ");
        int c2 = s2.empty() ? -1 : std::stoi(s2)-1;
        if (c2<0||c2>=8||board[c2].matched||board[c2].revealed||c2==c1) {
            board[c1].revealed = false;
            warn("Invalide."); sleepMs(200); continue;
        }
        board[c2].revealed = true;
        tries++;
        sleepMs(300);

        if (board[c1].pairId == board[c2].pairId) {
            board[c1].matched = board[c2].matched = true;
            matched++;
            ok("Paire! " + board[c1].content + " = " + board[c2].content);
        } else {
            err("Pas une paire!");
            board[c1].revealed = board[c2].revealed = false;
        }
        sleepMs(200);
    }

    cls();
    titleBox("MEMORY - VICTOIRE!", GREEN);
    mascot("Excellent! Memoire parfaite!");
    int score = std::max(0, 100 - (tries-4)*10);
    std::cout << "\n  En " << YELLOW << tries << RESET
              << " essais! Score: " << GREEN << score << "/100\n" << RESET;
    int xpG = score/5 * me.xpMultiplier;
    me.xp += xpG; me.gems += 4; me.achievementPoints += 20;
    saveUser(me);
    std::cout << "  " << ORANGE << "+" << xpG << " XP + 4 gemmes!" << RESET << "\n";
    pauseKey();
}

// ============================================================
// MINI-JEU : SPELLING BEE
// ============================================================

void spellingBeeGame() {
    if (me.lang.empty()) { err("Choisissez d'abord une langue!"); pauseKey(); return; }
    Language* lang = findLang(me.lang);
    if (!lang) return;

    std::vector<Vocab*> words;
    for (auto& les : lang->lessons)
        for (auto& v : les.vocab)
            words.push_back(&v);
    if (words.empty()) { info("Pas de mots."); pauseKey(); return; }

    srand((unsigned)time(nullptr));
    for (int i = (int)words.size()-1; i > 0; i--) {
        int j = rand()%(i+1); std::swap(words[i], words[j]);
    }

    int total = std::min(5, (int)words.size()), score = 0;
    cls();
    titleBox("EPELLE LES MOTS - " + lang->name, YELLOW);
    mascot("Epelle les mots!");
    std::cout << "\n  " << WHITE << "Francais -> " << lang->name << "\n\n";
    pauseKey();

    for (int i = 0; i < total; i++) {
        cls();
        titleBox("EPELLE LES MOTS", YELLOW);
        std::cout << "\n  " << (i+1) << "/" << total << "\n";
        progressBar(i, total, 40);
        std::cout << "\n  " << CYAN << "Mot francais: "
                  << YELLOW << BOLD << words[i]->french << RESET << "\n"
                  << "  " << DIM << "Prononciation: ["
                  << words[i]->pronunc << "]" << RESET << "\n\n";

        std::string ans     = prompt("En " + lang->name + ": ");
        std::string correct = words[i]->word;
        std::string al = ans, cl = correct;
        std::transform(al.begin(),al.end(),al.begin(),::tolower);
        std::transform(cl.begin(),cl.end(),cl.begin(),::tolower);

        if (al == cl) {
            score++;
            me.xp += 8 * me.xpMultiplier;
            me.gems++;
            ok("Correct! " + correct);
        } else {
            err("Reponse: " + correct);
        }
        pauseKey();
    }

    cls();
    titleBox("RESULTAT - SPELLING BEE", YELLOW);
    int pct = score * 100 / total;
    std::cout << "\n  " << GREEN << BOLD << score << "/" << total
              << " (" << pct << "%)" << RESET << "\n\n";
    progressBar(score, total, 40);
    me.achievementPoints += score * 8;
    saveUser(me);
    pauseKey();
}

// ============================================================
// ÉCRAN : MENU MINI-JEUX
// ============================================================

void miniGamesMenu() {
    while (true) {
        cls();
        titleBox("MINI-JEUX EDUCATIFS", MAGENTA);
        std::cout << "\n";
        showGems();
        std::cout << "\n";
        mascot("Jouons et apprenons!");
        std::cout << "\n";
        menuItem(1, "Pendu Linguistique     [15 pts + XP]");
        menuItem(2, "Memory Match           [20 pts + 4 gemmes]");
        menuItem(3, "Epelle les Mots        [8 pts/mot]");
        menuItem(0, "Retour", "<<");
        std::cout << "\n";

        std::string ch = prompt("Votre choix: ");
        if      (ch=="1") hangmanGame();
        else if (ch=="2") memoryGame();
        else if (ch=="3") spellingBeeGame();
        else if (ch=="0") return;
        else err("Choix invalide.");
    }
}

// ============================================================
// ÉCRAN : RÉVISION SRS (SM-2)
// ============================================================

void srsScreen() {
    if (me.lang.empty()) { err("Choisissez d'abord une langue!"); pauseKey(); return; }
    initSRSForLang(me.lang);

    long now = (long)time(nullptr);
    std::vector<SRSCard*> due;
    for (auto& c : mySRSCards)
        if (c.langCode == me.lang && c.nextReview <= now)
            due.push_back(&c);

    cls();
    titleBox("REVISION SRS - SM-2", LBLUE);
    std::cout << "\n";
    mascot("Revision au moment optimal!");
    std::cout << "\n  " << LBLUE << "Algorithme SM-2 - Repetition Espacee\n" << RESET
              << "  Cartes a reviser: " << YELLOW << due.size() << RESET << "\n\n";

    if (due.empty()) {
        ok("Aucune carte a reviser! Revenez demain.");
        pauseKey(); return;
    }

    srand((unsigned)time(nullptr));
    for (int i = (int)due.size()-1; i > 0; i--) {
        int j = rand() % (i+1);
        std::swap(due[i], due[j]);
    }

    int reviewed = 0;
    for (auto* card : due) {
        cls();
        titleBox("REVISION", LBLUE);
        std::cout << "\n  Carte " << (reviewed+1) << "/" << due.size() << "\n\n"
                  << "  " << YELLOW << BOLD << "  " << card->french << RESET << "\n\n"
                  << "  " << DIM << "(Pensez au mot en " << me.lang << "...)" << RESET << "\n";
        prompt("ENTREE pour voir la reponse: ");

        std::cout << "\n  Reponse: " << GREEN << BOLD << card->word << RESET << "\n\n"
                  << "  " << RED    << "[0]" << RESET << " Oublie total\n"
                  << "  " << ORANGE << "[1]" << RESET << " Presque oublie\n"
                  << "  " << YELLOW << "[2]" << RESET << " Difficile\n"
                  << "  " << CYAN   << "[3]" << RESET << " Correct (avec effort)\n"
                  << "  " << GREEN  << "[4]" << RESET << " Correct\n"
                  << "  " << GREEN  << "[5]" << RESET << " Parfait!\n\n";

        std::string qStr = prompt("Note (0-5): ");
        int q = qStr.empty() ? 3 : std::stoi(qStr);
        if (q < 0) q = 0;
        if (q > 5) q = 5;

        sm2Update(*card, q);
        reviewed++;
        me.srsCardsReviewed++;

        if (q >= 4) {
            me.xp += 5 * me.xpMultiplier; me.gems++;
            ok("+5 XP + 1 gemme! Prochaine revision dans "
               + std::to_string(card->interval) + " jour(s)");
        } else if (q >= 3) {
            me.xp += 3;
            ok("+3 XP. Prochaine revision dans "
               + std::to_string(card->interval) + " jour(s)");
        } else {
            info("A retravailler! Revision demain.");
        }
        pauseKey();
    }

    saveSRS();
    saveUser(me);
    cls();
    titleBox("REVISION TERMINEE", GREEN);
    mascot("La memoire se renforce!");
    std::cout << "\n  Cartes revisees : " << YELLOW << reviewed << RESET << "\n";
    pauseKey();
}

// ============================================================
// ÉCRAN : CONTENU CULTUREL
// ============================================================

void culturalScreen() {
    while (true) {
        cls();
        titleBox("CONTENU CULTUREL", ORANGE);
        std::cout << "\n";
        for (int i = 0; i < (int)langs.size(); i++)
            menuItem(i+1, langs[i].name);
        menuItem(0, "Retour", "<<");
        std::cout << "\n";

        std::string ch = prompt("Choisir une langue: ");
        if (ch == "0") return;
        int idx = ch.empty() ? -1 : std::stoi(ch)-1;
        if (idx < 0 || idx >= (int)langs.size()) { err("Invalide."); continue; }
        Language& lang = langs[idx];

        while (true) {
            cls();
            titleBox("CULTURE - " + lang.name, ORANGE);
            std::cout << "\n";
            menuItem(1, "Proverbes et Sagesse");
            menuItem(2, "Histoires et Legendes");
            menuItem(0, "Retour", "<<");
            std::cout << "\n";

            std::string c2 = prompt("Votre choix: ");
            if (c2 == "0") break;

            if (c2 == "1") {
                cls();
                titleBox("PROVERBES - " + lang.name, YELLOW);
                std::cout << "\n";
                if (lang.proverbs.empty()) {
                    info("Pas de proverbes.");
                } else {
                    for (auto& p : lang.proverbs) {
                        hline(ORANGE, '-');
                        std::cout << "\n  " << ORANGE << BOLD
                                  << "\"" << p.original << "\"" << RESET << "\n"
                                  << "  " << YELLOW << p.french << RESET << "\n"
                                  << "  " << DIM << "Sens: " << p.meaning << RESET << "\n\n";
                    }
                }
                me.gems++; me.achievementPoints += 5;
                saveUser(me);
                ok("+1 gemme pour votre curiosite culturelle!");
                pauseKey();

            } else if (c2 == "2") {
                cls();
                titleBox("HISTOIRES - " + lang.name, CYAN);
                std::cout << "\n";
                if (lang.stories.empty()) {
                    info("Pas d'histoires.");
                } else {
                    for (auto& s : lang.stories) {
                        hline(CYAN, '-');
                        std::cout << "\n  " << CYAN << BOLD << s.title << RESET << "\n\n"
                                  << "  " << s.text << "\n\n";
                    }
                }
                me.gems++; me.achievementPoints += 5;
                saveUser(me);
                ok("+1 gemme pour votre curiosite culturelle!");
                pauseKey();

            } else {
                err("Invalide.");
            }
        }
    }
}

// ============================================================
// ÉCRAN : TABLEAU DES LEADERS
// ============================================================

void leaderboardScreen() {
    cls();
    titleBox("TABLEAU DES LEADERS", GOLD);
    std::cout << "\n";
    mascot("Les meilleurs apprenants!");
    std::cout << "\n";

    struct LEntry { std::string name, code; int xp, streak; };
    std::vector<LEntry> entries;
    std::ifstream fin("camlex_users.dat");
    std::string   ln;
    while (std::getline(fin, ln)) {
        std::istringstream       ss(ln);
        std::vector<std::string> tok;
        std::string              t;
        while (std::getline(ss, t, '|')) tok.push_back(t);
        if (tok.size() >= 4) {
            LEntry e;
            e.code   = tok[0]; e.name   = tok[1];
            e.xp     = std::stoi(tok[3]);
            e.streak = tok.size()>4 ? std::stoi(tok[4]) : 0;
            entries.push_back(e);
        }
    }
    fin.close();
    std::sort(entries.begin(), entries.end(),
              [](const LEntry& a, const LEntry& b){ return a.xp > b.xp; });

    hline(GOLD, '=');
    std::cout << GOLD << "  Rang  Nom                    XP      Serie\n";
    hline(GOLD, '-');
    std::string medals[] = {"[1]","[2]","[3]"};
    for (int i = 0; i < (int)entries.size() && i < 10; i++) {
        std::string medal = i < 3 ? medals[i] : "   ";
        bool        isMe  = entries[i].code == me.code;
        std::string col   = isMe ? GREEN : (i==0 ? GOLD : WHITE);
        std::cout << col << "  " << medal << "   "
                  << std::left << std::setw(22) << entries[i].name
                  << std::setw(8) << entries[i].xp
                  << entries[i].streak << " j"
                  << (isMe ? "  <<< TOI" : "")
                  << RESET << "\n";
    }
    hline(GOLD, '=');
    std::cout << "\n  Total joueurs: " << YELLOW << entries.size() << RESET << "\n";
    pauseKey();
}

// ============================================================
// ÉCRAN : DÉFI QUOTIDIEN
// ============================================================

void dailyChallengeScreen() {
    cls();
    titleBox("DEFI QUOTIDIEN", ORANGE);
    std::cout << "\n";

    long now  = (long)time(nullptr);
    long dayS = (now / 86400) * 86400;

    if (me.lastDailyChallenge >= dayS) {
        mascot("Defi deja accompli aujourd'hui!");
        ok("Reviens demain pour le prochain defi!");
        std::cout << "  " << GOLD << "Gemmes: " << me.gems << " [*]" << RESET << "\n";
        pauseKey(); return;
    }
    if (me.lang.empty()) { err("Choisissez d'abord une langue!"); pauseKey(); return; }
    Language* lang = findLang(me.lang);
    if (!lang || lang->quiz.empty()) { info("Pas de contenu."); pauseKey(); return; }

    mascot("Releve le defi du jour!");
    std::cout << "\n  " << YELLOW << "Recompense: " << GOLD << "+15 gemmes + x2 XP\n" << RESET
              << "  Le defi: 3 questions!\n\n";
    pauseKey();

    srand((unsigned)time(nullptr));
    int total = std::min(3, (int)lang->quiz.size()), score = 0;

    for (int i = 0; i < total; i++) {
        auto& q = lang->quiz[i % (int)lang->quiz.size()];
        cls();
        titleBox("DEFI - Q" + std::to_string(i+1), ORANGE);
        std::cout << "\n" << WHITE << BOLD << "  " << q.text << RESET << "\n\n";
        char labels[] = {'A','B','C','D'};
        for (int j = 0; j < 4; j++)
            if (!q.opts[j].empty())
                std::cout << "  " << CYAN << "[" << labels[j] << "] "
                          << RESET << q.opts[j] << "\n";
        std::cout << "\n";

        std::string ans = prompt("Reponse: ");
        int uIdx = -1;
        if (!ans.empty()) {
            char c = (char)toupper(ans[0]);
            if (c>='A' && c<='D') uIdx = c - 'A';
        }
        if (uIdx == q.correct) { score++; ok("Correct!"); }
        else { err("Incorrect! " + std::string(1, labels[q.correct])); }
        pauseKey();
    }

    if (score >= 2) {
        me.gems += 15; me.xpMultiplier = 2;
        me.challengeWins++; me.lastDailyChallenge = now;
        me.achievementPoints += 30;
        saveUser(me);
        titleBox("DEFI REUSSI!", GOLD);
        mascot("Champion! +15 gemmes!");
        std::cout << "\n  " << GOLD << "+15 gemmes + x2 XP active!\n" << RESET;
        ok("Multiplicateur x2 XP actif pour cette session!");
    } else {
        me.lastDailyChallenge = now;
        saveUser(me);
        err("Defi echoue (" + std::to_string(score) + "/3). Reessaie demain!");
    }
    pauseKey();
}

// ============================================================
// ÉCRAN : BOUTIQUE DES GEMMES
// ============================================================

void gemsShopScreen() {
    while (true) {
        cls();
        titleBox("BOUTIQUE DES GEMMES", GOLD);
        std::cout << "\n"; showGems(); std::cout << "\n";
        menuItem(1, "Multiplicateur x2 XP       (10 gemmes)");
        menuItem(2, "Indice quiz gratuit         (5 gemmes)");
        menuItem(3, "Voir mon rang de ligue");
        menuItem(0, "Retour", "<<");
        std::cout << "\n";

        std::string ch = prompt("Votre choix: ");
        if (ch == "0") return;

        if (ch == "1") {
            if (me.gems >= 10) {
                me.gems -= 10; me.xpMultiplier = 2; saveUser(me);
                ok("Multiplicateur x2 XP active!");
            } else {
                err("Pas assez de gemmes! (besoin: 10)");
            }
        } else if (ch == "2") {
            if (me.gems >= 5) {
                me.gems -= 5; saveUser(me);
                ok("Indice: Concentrez-vous sur les mots de la Lecon 1!");
            } else {
                err("Pas assez de gemmes! (besoin: 5)");
            }
        } else if (ch == "3") {
            static const char* ranks[]  = {"BRONZE","ARGENT","OR","PLATINE","DIAMANT"};
            static const char* rcolors[]= {
                "\033[38;5;208m","\033[37m",GOLD,"\033[38;5;147m","\033[38;5;51m"
            };
            if      (me.xp>=500) me.leagueRank=4;
            else if (me.xp>=300) me.leagueRank=3;
            else if (me.xp>=150) me.leagueRank=2;
            else if (me.xp>=50)  me.leagueRank=1;
            else                 me.leagueRank=0;
            int r = me.leagueRank;
            std::cout << "\n  " << rcolors[r] << BOLD
                      << "Rang: " << ranks[r] << RESET << "\n";
            saveUser(me);
        } else {
            err("Invalide.");
        }
        pauseKey();
    }
}

// ============================================================
// ÉCRAN : GAMIFICATION HUB
// ============================================================

void gamificationScreen() {
    while (true) {
        cls();
        titleBox("GAMIFICATION & RECOMPENSES", GOLD);
        std::cout << "\n"; showGems(); std::cout << "\n";
        menuItem(1, "Defi Quotidien");
        menuItem(2, "Boutique des Gemmes");
        menuItem(3, "Tableau des Leaders");
        menuItem(0, "Retour", "<<");
        std::cout << "\n";

        std::string ch = prompt("Votre choix: ");
        if (ch == "0") return;
        if      (ch=="1") dailyChallengeScreen();
        else if (ch=="2") gemsShopScreen();
        else if (ch=="3") leaderboardScreen();
        else err("Invalide.");
    }
}

// ============================================================
// ÉCRAN : TUTEUR IA
// ============================================================

void aiTutorScreen() {
    cls();
    titleBox("TUTEUR IA PERSONNALISE", LBLUE);
    std::cout << "\n"; mascot("Je suis ton tuteur IA!"); std::cout << "\n";
    std::cout << "  " << LBLUE << "Analyse de votre profil...\n" << RESET;
    sleepMs(400);

    hline(LBLUE, '-');
    std::cout << "\n  " << YELLOW << "ANALYSE IA:\n\n" << RESET;

    if (me.xp == 0 && me.lessonsCompleted == 0) {
        std::cout << "  " << CYAN << ">> Debutant absolu detecte!\n" << RESET
                  << "  Recommandation: Commencez par la Lecon 1.\n"
                  << "  Objectif: 3 lecons cette semaine.\n";
    } else if (me.quizBest < 50) {
        std::cout << "  " << ORANGE << ">> Difficultes au quiz!\n" << RESET
                  << "  Recommandation: Revoyez les lecons avant le quiz.\n"
                  << "  Utilisez la Revision SRS pour renforcer la memoire.\n";
    } else if (me.streak < 3) {
        std::cout << "  " << YELLOW << ">> Serie trop courte!\n" << RESET
                  << "  Recommandation: Connectez-vous chaque jour.\n"
                  << "  Conseil: 10min/jour > 1h une fois par semaine.\n";
    } else if (me.lessonsCompleted < 5) {
        std::cout << "  " << GREEN << ">> Bon debut! Continuez.\n" << RESET
                  << "  Recommandation: Essayez les mini-jeux!\n";
    } else {
        std::cout << "  " << GREEN << ">> Excellent progres!\n" << RESET
                  << "  Recommandation: Defi quotidien pour le x2 XP.\n"
                  << "  Explorez le contenu culturel.\n";
    }

    std::cout << "\n"; hline(LBLUE, '-');
    std::cout << "\n  " << YELLOW << "PROGRESSION EN COURS:\n" << RESET;

    if (!me.lang.empty()) {
        Language* lang = findLang(me.lang);
        if (lang) {
            int total = 0;
            for (auto& l : lang->lessons) total += (int)l.vocab.size();
            int pct = total > 0
                    ? std::min(100, (int)(100.0 * me.totalWordsLearned / total))
                    : 0;
            std::cout << "\n  " << lang->name << ":\n";
            progressBar(pct, 100, 40);
            if      (pct < 30) std::cout << "  " << RED    << "Debutant - Continuez!\n"           << RESET;
            else if (pct < 70) std::cout << "  " << YELLOW << "Intermediaire - Bonne progression!\n" << RESET;
            else               std::cout << "  " << GREEN  << "Avance - Bien maitrise!\n"          << RESET;
        }
    }

    std::cout << "\n  " << LBLUE << "Plan personnalise:\n" << RESET;
    std::cout << "  [" << (me.lessonsCompleted>=3 ? (GREEN "OK" RESET) : (RED "  " RESET)) << "] 3 lecons completees\n";
    std::cout << "  [" << (me.quizBest>=70        ? (GREEN "OK" RESET) : (RED "  " RESET)) << "] Quiz > 70%\n";
    std::cout << "  [" << (me.streak>=5            ? (GREEN "OK" RESET) : (RED "  " RESET)) << "] Serie de 5 jours\n";
    std::cout << "  [" << (me.srsCardsReviewed>=10 ? (GREEN "OK" RESET) : (RED "  " RESET)) << "] 10 cartes SRS revisees\n";

    pauseKey();
}

// ============================================================
// ÉCRAN : PERSONNALISATION
// ============================================================

void customizationScreen() {
    while (true) {
        cls();
        titleBox("PERSONNALISATION", PURPLE);
        std::cout << "\n  Theme actuel: ";
        if      (me.theme == 0) std::cout << CYAN          << "Defaut (Cyan/Orange)"  << RESET;
        else if (me.theme == 1) std::cout << "\033[38;5;33m"  << "Nuit (Bleu fonce)"    << RESET;
        else                    std::cout << "\033[38;5;198m" << "Festif (Rose/Vert)"   << RESET;
        std::cout << "\n  Multiplicateur XP: "
                  << ORANGE << "x" << me.xpMultiplier << RESET << "\n\n";

        menuItem(1, "Theme Defaut  (Cyan/Orange)");
        menuItem(2, "Theme Nuit    (Bleu fonce)");
        menuItem(3, "Theme Festif  (Rose/Vert)");
        menuItem(4, "Activer x2 XP (10 gemmes si inactif)");
        menuItem(5, "Desactiver x2 XP");
        menuItem(0, "Retour", "<<");
        std::cout << "\n";

        std::string ch = prompt("Votre choix: ");
        if (ch == "0") return;

        if      (ch=="1") { me.theme=0; saveUser(me); ok("Theme Defaut active!"); }
        else if (ch=="2") { me.theme=1; saveUser(me); ok("Theme Nuit active!"); }
        else if (ch=="3") { me.theme=2; saveUser(me); ok("Theme Festif active!"); }
        else if (ch=="4") {
            if (me.xpMultiplier > 1)   { info("Multiplicateur deja actif!"); }
            else if (me.gems >= 10)     { me.gems-=10; me.xpMultiplier=2; saveUser(me); ok("x2 XP active!"); }
            else                        { err("Pas assez de gemmes! (10 requis)"); }
        }
        else if (ch=="5") { me.xpMultiplier=1; saveUser(me); ok("Multiplicateur reinitialise."); }
        else err("Invalide.");
        pauseKey();
    }
}

// ============================================================
// ÉCRAN : À PROPOS
// ============================================================

void aboutScreen() {
    cls();
    titleBox("A PROPOS DE CAMLEX v2.0", CYAN);
    mascot("Je suis Phenix, ta mascotte!");
    std::cout << "\n"
              << "  CAMlex - Apprentissage des langues camerounaises\n\n"
              << "  " << YELLOW << "Nouveautes v2.0:\n" << RESET
              << "  - Gamification (gemmes, defis, ligue, badges)\n"
              << "  - Mini-jeux (Pendu, Memory, Spelling Bee)\n"
              << "  - Revision SRS (algorithme SM-2)\n"
              << "  - Tuteur IA personnalise\n"
              << "  - Contenu culturel (proverbes, histoires)\n"
              << "  - Tableau des leaders\n"
              << "  - Personnalisation (3 themes)\n"
              << "  - Notes culturelles dans les lecons\n\n"
              << "  " << YELLOW << "Langues:\n" << RESET;
    for (auto& l : langs)
        std::cout << "  - " << GREEN << l.name << RESET
                  << " (" << l.region << ")\n";
    std::cout << "\n  " << DIM
              << "Compilation: g++ -o camlex main.cpp ui.cpp data.cpp user.cpp srs.cpp -std=c++11 -lm\n"
              << "  Preservons notre patrimoine linguistique!\n" << RESET;
    pauseKey();
}

// ============================================================
// MENU PRINCIPAL
// ============================================================

void mainMenu() {
    while (true) {
        cls();
        printLogo();
        hline(themeMain(), '=');
        std::cout << themeMain() << " Joueur: " << themeAccent() << BOLD << me.name << RESET
                  << themeMain() << "  |  XP: " << themeHdr() << me.xp << RESET
                  << themeMain() << "  |  Serie: " << ORANGE << me.streak << RESET
                  << themeMain() << "  |  "
                  << masteryColor(me.xp) << masteryName(me.xp) << RESET << "\n";
        showGems();
        hline(themeMain(), '=');
        std::cout << "\n"
                  << themeMain() << "  +------------------------------------+\n"
                  << "  |         MENU PRINCIPAL             |\n"
                  << "  +====================================+\n" << RESET;

        menuItem(1,  "Lecons");
        menuItem(2,  "Quiz");
        menuItem(3,  "Mini-jeux");
        menuItem(4,  "Revision SRS");
        menuItem(5,  "Tuteur IA");
        menuItem(6,  "Culture");
        menuItem(7,  "Ma Progression");
        menuItem(8,  "Dictionnaire");
        menuItem(9,  "Gamification & Defis");
        menuItem(10, "Personnalisation");
        menuItem(11, "A propos");
        menuItem(0,  "Quitter", "XX");

        std::cout << themeMain() << "  +------------------------------------+\n"
                  << RESET << "\n";

        std::string ch = prompt("Votre choix: ");
        if      (ch=="1")  lessonsMenu();
        else if (ch=="2")  quizScreen();
        else if (ch=="3")  miniGamesMenu();
        else if (ch=="4")  srsScreen();
        else if (ch=="5")  aiTutorScreen();
        else if (ch=="6")  culturalScreen();
        else if (ch=="7")  progressScreen();
        else if (ch=="8")  dictionaryScreen();
        else if (ch=="9")  gamificationScreen();
        else if (ch=="10") customizationScreen();
        else if (ch=="11") aboutScreen();
        else if (ch=="0") {
            cls();
            centered("A bientot, " + me.name + "!", GREEN);
            centered("Continuez a apprendre nos langues!", YELLOW);
            std::cout << "\n";
            exit(0);
        } else {
            err("Choix invalide! Entrez un chiffre de 0 a 11.");
        }
    }
}
